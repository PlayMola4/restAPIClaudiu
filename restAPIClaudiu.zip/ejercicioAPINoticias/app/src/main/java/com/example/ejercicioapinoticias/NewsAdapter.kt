package com.example.ejercicioapinoticias

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class NewsAdapter(private var news: List<Inmueble>): RecyclerView.Adapter<NewsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bind(inmueble: Inmueble) {
            itemView.setOnClickListener{

                println("item pulsado")

            }
            itemView.findViewById<TextView>(R.id.tvTitle).text = inmueble.titulo
            itemView.findViewById<TextView>(R.id.tvUbicacion).text = inmueble.ubicacion
            itemView.findViewById<TextView>(R.id.tvDescripcion).text = inmueble.descripcion
        }


    }




    fun setList(lista2:MutableList<Inmueble>){
        this.news = lista2
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.row_manus, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = news.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(news[position])
    }
}