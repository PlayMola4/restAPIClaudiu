package com.example.ejercicioapinoticias



import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*

interface NewsApi {
    @GET("v2/top-headlines")
    fun getTopHeadlines(
        @Query("country") country: String,
        @Query("apiKey") apiKey: String,
        @Query("pageSize") pageSize: Int
    ): Call<Inmueble>

    @GET("v2/top-headlines")
    fun getTopHeadlinesNombre(
        @Query("country") country: String,
        @Query("apiKey") apiKey: String,
        @Query("pageSize") pageSize: Int,
        @Query("q") q:String
    ): Call<Inmueble>

    @GET("inmuebles/")
    fun GetListInmuebles(): Call<List<Inmueble>>

    @POST("inmuebles/")
    fun postMyData(@Body data: Inmueble): Call<Inmueble>

    @DELETE
    fun deleteInmuebleByTitle(@Url url:String): Call<Void>

    @POST
    fun updateInmueble(@Url url:String, @Body samirClass: Inmueble): Call<Inmueble>
}