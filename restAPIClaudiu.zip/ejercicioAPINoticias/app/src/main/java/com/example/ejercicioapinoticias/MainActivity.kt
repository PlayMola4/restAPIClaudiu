package com.example.ejercicioapinoticias

import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var newsRecyclerView: RecyclerView
    private lateinit var adapter: NewsAdapter
    private lateinit var textView: TextView
    private lateinit var lista: MutableList<Inmueble>
    private lateinit var searchView: androidx.appcompat.widget.SearchView
    private lateinit var newsAPI: NewsApi
    private var allCards = mutableListOf<Inmueble>()
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var btnPOST : Button
    private lateinit var btnPUT : Button
    private lateinit var btnDELETE : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        newsRecyclerView = findViewById(R.id.rvMain)
        btnPOST = findViewById(R.id.btnPost)
        btnPUT = findViewById(R.id.btnPut)
        btnDELETE = findViewById(R.id.btnDelete)
        adapter = NewsAdapter(allCards)
        newsRecyclerView.adapter = adapter
        searchView = findViewById(R.id.searchview)
        newsRecyclerView.layoutManager = LinearLayoutManager(this)
        lista = mutableListOf()

        textView = findViewById(R.id.tvNo)

        textView.visibility = View.VISIBLE
        textView.text = "Cargando noticias..."
        buscarInmuebles()
        aniadirInmuebles()
        deleteInmueble()
        updateInmueble()

       /*searchView.setOnQueryTextListener(object :
            SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newsApi.GetListInmuebles()
                    .enqueue(object : Callback<NewsResponse> {
                        override fun onResponse(
                            call: Call<NewsResponse>,
                            response: Response<NewsResponse>
                        ) {

                           if (response.isSuccessful) {
                               val result = response.body()!!.articles
                               adapter.setList(result as MutableList<News>)
                           }
                        }

                        override fun onFailure(call: Call<NewsResponse>, t: Throwable) {
                            println("Error")
                        }
                    })
                return true
            }
        })*/
    }

    private fun buscarInmuebles() {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.10.30.136:8080/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val inmueblesService = retrofit.create(NewsApi::class.java)
        textView.visibility = View.VISIBLE
        // Se crea un Listener para la respuesta de la llamada a la API
        inmueblesService.GetListInmuebles()
            .enqueue(object : Callback<List<Inmueble>> {
                // Se define la acción a realizar en caso de éxito en la llamada
                override fun onResponse(
                    call: Call<List<Inmueble>>,
                    response: Response<List<Inmueble>>
                ) {
                    val inmueble = response.body()
                    allCards.addAll(inmueble!!)

                    if (response.isSuccessful) {
                        textView.visibility = View.INVISIBLE
                        adapter.setList(allCards)
                        newsRecyclerView.adapter = adapter


                    }
                }

                override fun onFailure(call: Call<List<Inmueble>>, t: Throwable) {
                    textView.visibility = View.VISIBLE
                    textView.text = "No hay inmuebles"
                    println(call.toString())
                    println(t.toString())
                }
            })
    }

    private fun aniadirInmuebles() {
        btnPOST.setOnClickListener {

            CoroutineScope(Dispatchers.IO).launch {

                val retrofit = Retrofit.Builder()
                    .baseUrl("http://10.10.30.136:8080/api/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

                val myApi = retrofit.create(NewsApi::class.java)

                val myData = Inmueble(
                    "IES Murgino", 20.0f, "El mejor instituto de todos", 15, 10, "El Ejido",
                    "institutos", "2020-01-23", 4, 3
                )

                myApi.postMyData(myData).enqueue(object : Callback<Inmueble> {

                    override fun onFailure(call: Call<Inmueble>, t: Throwable) {

                    }

                    override fun onResponse(
                        call: Call<Inmueble>,
                        response: Response<Inmueble>
                    ) {
                        if (response.isSuccessful) {
                            val myResponse = response.body()
                            Log.i("POST", "realizado con exito con la ID: " + myResponse?.idInmueble.toString())
                            newsRecyclerView.adapter?.notifyDataSetChanged()
                        } else {
                            System.err.println(response.errorBody()?.string())
                        }
                    }
                })
            }
        }
    }

    private fun deleteInmueble() {
        btnDELETE.setOnClickListener {

            val retrofit = Retrofit.Builder()
                .baseUrl("http://10.10.30.136:8080/api/inmuebles/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()


            val myApi = retrofit.create(NewsApi::class.java)

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Ingresa la ID a borrar")

            // Configura el cuadro de texto de entrada
            val input = EditText(this)
            input.inputType = InputType.TYPE_CLASS_NUMBER
            builder.setView(input)

            // Agrega el botón "Aceptar"
            builder.setPositiveButton("Aceptar") { dialog, which ->
                val number = input.text.toString().toInt()


                myApi.deleteInmuebleByTitle(input.text.toString()).enqueue(object : Callback<Void> {
                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        Log.i("Borrado", "Borrado completado")
                        newsRecyclerView.adapter?.notifyDataSetChanged()
                    }

                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        Log.i("Borrado", "Ha habido un error al borrar la ID")
                    }

                })
            }
            builder.setNegativeButton("Cancelar") { dialog, which ->
                dialog.cancel()
            }

            builder.show()
        }
    }

    private fun updateInmueble() {
        btnPUT.setOnClickListener {

            val retrofit = Retrofit.Builder()
                .baseUrl("http://10.10.30.136:8080/api/inmuebles/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val myApi = retrofit.create(NewsApi::class.java)

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Ingresa un numero para editar")

            // Configura el cuadro de texto de entrada
            val input = EditText(this)
            input.inputType = InputType.TYPE_CLASS_NUMBER
            builder.setView(input)

            // Agrega el botón "Aceptar"
            builder.setPositiveButton("Aceptar") { dialog, which ->
                val number = input.text.toString().toInt()



                val myData = Inmueble(
                    "IES Murgino las Palomas", 20.0f, "El mejor instituto de todos los tiempos", 15, 10, "El Ejido",
                    "institutos", "2020-01-23", 4, 3
                )

                var ruta = "" + number
                myApi.updateInmueble(ruta, myData).enqueue(object : Callback<Inmueble> {
                    override fun onResponse(
                        call: Call<Inmueble>,
                        response: Response<Inmueble>
                    ) {
                        Log.i("Update", "Actualizcion de inmueble realizada con exito")
                        newsRecyclerView.adapter?.notifyDataSetChanged()
                    }

                    override fun onFailure(call: Call<Inmueble>, t: Throwable) {
                        Log.i("Update", "No se ha podido actualizar la ID")
                    }
                })

            }

            builder.setNegativeButton("Cancelar") { dialog, which ->
                dialog.cancel()
            }

            builder.show()


        }
    }
}
